%% 1)
[s, Fs] = audioread('xkubic39.wav');
s = s';
N = length(s);
t = (0:(N-1)) / Fs;


% Vzorkovaci frekvence signalu: 16000 Hz
% Delka signalu ve vzorcich: 16000
% Delka signalu v sekundach: 1 s
disp(['Vzorkovaci frekvence signalu: ' num2str(Fs) ' Hz']);
disp(['Delka signalu ve vzorcich: ' num2str(N) ' vzorku']);
disp(['Delka signalu v sekundach: ' num2str(N/Fs) ' s']);

%% 2)
x = abs(fft(s));
f = (0:Fs-1);

x2 = x(1:8000);
f2 = f(1:8000);
figure(2);
plot(f2,x2); title('Spektrum signalu xkubic39 pomoci DFT'); xlabel('f [Hz]'); ylabel('Magnitude'); grid minor;

%% 3)
[kolik, kde] = max(x);
% 269 ~ 270 Hz
disp(['Maximum modulu spektra puvodniho signalu je na frekvenci: ' num2str(kde) ' Hz']);


%% 4)
% koeficieny IIR
b = [0.2324 -0.4112 0.2324];
a = [1 0.2289 0.4662];

% vykresleni polu a nul
figure(4);
zplane (b,a);
title('Jednotkova kruznice s nulami a poly');
disp('Filtr je stabilni nebot nuly a poly se nachazi uvitr jednotkove kruznice.');

%% 5)
figure(5);
H = freqz(b,a,256); f=(0:255) / 256 * Fs / 2; 
plot (f,abs(H)); grid; xlabel('f [Hz]'); ylabel('|H(f)|');
title('Modul kmitoctove charakteristiky filtru');

% horni propust
disp('Filtr je typu: horni propust');

%% 6)
sf = filter(b,a,s);
fx = abs(fft(sf));
fx2 = fx(1:8000);
figure(6);
plot(f2,fx2); title('Spektrum filtrovaneho signalu xkubic39 pomoci DFT'); xlabel('f [Hz]'); ylabel('Magnitude'); grid minor;

%% 7)
[kolik, kde] = max(fx2);
disp(['Maximum modulu spektra odfiltrovaneho signalu je na frekvenci: ' num2str(kde) ' Hz']);

%% 8)
h = sum(abs(s)) / N;
ps1 = [h h h h -h -h -h -h];
ps = fliplr(repmat(ps1, 1, 40));

fin_filt = filtfilt(ps,1,s);
[kolik, kde] = max(abs(fin_filt));
 
sample = kde-158; % kde je stred, minus polovina delky vzorku obdelniku je zacatek
time = sample/Fs;

disp(['20 ms obdelnikovych impulsu se nachazi od vzorku: ' num2str(sample) ' v case: ' num2str(time*1000) ' ms']);

% figure;
% subplot(1,2,1); plot(filtfilt(ps,1,s)); title('filtfilt');
% subplot(1,2,2); plot(filter(ps,1,s)); title('filter');

%% 9)
R = xcorr(s,50,'biased');
figure(9);
stem([-50:50],R); grid minor;
title('Autokorelacni koeficienty R[k]');
xlabel('k');

%% 10)
disp(['Autokorelacni koeficient R[10]: ' num2str(R(61))]);

%% 11)
% rozdil mezi signaly je deset vzorku tak je treba je posunout vzajemne,
% ale zachovat jejich delku stejnou

s1 = [s 0 0 0 0 0 0 0 0 0 0];
s2 = [0 0 0 0 0 0 0 0 0 0 s];
vzorkovani = [-1:0.05:1];  % vektor od -1:1 , zvolit si krok

[h,p,r] = hist2opt(s1,s2, vzorkovani);
figure(11);
surfc(p);
title('Hustota rozdeleni pravdepodobnosti p(x1,x2,10)');

%% 12)
 % hist2: check -- 2d integral should be 1 and is 1
 
%% 13)
% promenna r z funkce hist2opt
disp(['Autokorelacni koeficient R[10] podle funkce hustoty rozdeleni pravdepodobnosti: ' num2str(r)]);
 

